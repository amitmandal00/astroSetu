# Cursor Operational Guide (Report Generation)

This is the workflow Cursor must follow when changing anything related to AI Astrology report generation.

## MVP goals contract (must drive all decisions)
**Primary intent**: simplified, robust (NOT over-engineered), minimal dependency on third‑party schedulers (cron is only a backstop).

**One‑line MVP definition**:
> “A user pays once, waits calmly, always gets a report or no charge — and the system never leaks money or breaks under retries.”

- **1) Payment protection**: manual capture; capture only after report is `completed` with content; failures never capture; opportunistic cleanup + cron backstop; no double charges (idempotent).
- **2) Robust generation UX**: async worker; frontend order→poll→render; single status vocabulary `processing|completed|failed`; preview reload resumes polling; never auto re-enqueue.
- **3) No cost leakage**: no OpenAI/Prokerala before payment authorization; `max_attempts=2`; OpenAI timeout ≤ 25s; degrade once then fail cleanly; no infinite retries.
- **4) Fast perceived performance**: redirect to preview quickly; progress vocabulary queued→generating→validating→ready; first feedback <2s; no blank screens >3s.
- **5) Stable build**: strict status vocabulary; hardened worker auth; one job = one report = one payment; no stuck processing/orphan payments.
- **6) Quality without over-engineering**: minimum section validation; fallback sections; quality metrics logged (not blocking when minimum bar met).
- **7) Retry rules**: retry only if `failed`; within 24h; max 1 manual retry; reuse same authorized PaymentIntent; no double-billing; then auto-cancel/expire.
- **8) Not in MVP**: streaming tokens UI, full bundle API-first migration, multi-language engines, human support workflows, perfect astrology depth.

## NON-NEGOTIABLES

### 🚨 GIT WORKFLOW - MANDATORY APPROVAL (CRITICAL)
- **ALWAYS keep all changes**: Commit locally to preserve work (`git add` and `git commit` are fine)
- **ALWAYS take approval before git push**: **NEVER** push to remote without explicit user approval
- **Show what will be pushed**: Display commit summary and changed files before asking for approval
- **Wait for confirmation**: Do not proceed with `git push` until user explicitly approves

**This is a NON-NEGOTIABLE rule that cannot be bypassed under any circumstances.**

---

### Technical NON-NEGOTIABLES

- **Minimal diff rule**: fix only the defect; no unrelated refactors.
- **Timer monotonic invariant**: while the generation UI is visible, elapsed time must **never** reset to 0 and must **never** decrease.
- **Idle-only resets**: do not clear `loading`, `loadingStage`, `loadingStartTime`, `loadingStartTimeRef`, or generation locks while an attempt is active/starting.
- **Owner model**: controller vs legacy flow must be mutually exclusive; switching must be explicit.
- **URL contract**: use `session_id` (snake_case) for paid-flow continuity.

Reference contract: `tests/contracts/report-flow.contract.md`.

## Fast E2E (best practice)
- **Stabilization/CI should NOT use `next dev`** for E2E. Prefer `next build && next start` to eliminate on-demand compilation variance.
- **Parallelize Playwright** once stable (`--workers=N` or `--workers=50%`).
- **Shard in CI** (`--shard=k/n`) for wall-clock speedups.
- **Separate slow invariants** (first-load/cold-start) into a dedicated job (nightly or a gated suite).

## Avoid Cursor/tool interruptions
- **Always tee long runs to log files** (and background when appropriate) so “User aborted request” banners don’t cost progress:
  - `npm run test:all-layers 2>&1 | tee .cursor-test-all-layers.log`
  - `npx playwright test 2>&1 | tee .cursor-e2e.log`

## Subscription flow (monthly) — NON-NEGOTIABLES

- Client **never** calls Stripe directly. It must call server routes and then `window.location.href = session.url`.
- No “subscription active” state sourced from `sessionStorage` (except a temporary UX banner).
- DB/API (Supabase via `/api/billing/subscription`) is the source of truth.
- Success redirect must verify `session_id` server-side (`/api/billing/subscription/verify-session`) and then redirect to `/ai-astrology/subscription` (clean URL).
- Verification must be idempotent (safe to call twice).

## Standard workflow (do not skip steps)

### 1) Reproduce + isolate
- Identify the exact user journey (fresh load vs transition vs retry).
- Locate the single source of truth for:
  - **UI visibility** (processing screen)
  - **timer** (start time source)
  - **polling** (attempt/cancel guards)

### 2) Add a reproducer test first
- UI/timer defects → add/update a Playwright spec in `tests/e2e/`.
- The test must encode the invariant (ex: “elapsed never decreases”).

### 3) Implement the smallest fix
- Prefer local guards over broad rewrites.
- Never introduce new global state or new “second source of truth”.

### 4) Verify locally (targeted)
- Run the smallest relevant subset:

```bash
cd astrosetu

# Targeted unit tests
npx vitest run tests/unit/lib/lifeSummary-engagement.test.ts tests/unit/lib/freeReportGating.test.ts

# Targeted E2E regression
npx playwright test tests/e2e/year-analysis-first-load-timer-monotonic.spec.ts
```

If you need the full critical gate:

```bash
cd astrosetu
npm run ci:critical
```

**CRITICAL - Test Coverage Requirements (2026-01-21)**:
- **Always update tests when changing code**: Every code change must include corresponding test updates
- **Run tests after every change**: `npm run test:unit` must pass before proceeding
- **Coverage thresholds**: Lines 70%, Functions 70%, Branches 65%, Statements 70%
- **Generate coverage reports**: `npm run test:unit:coverage` to verify thresholds
- **Test validation logic thoroughly**: Validation functions must have comprehensive test coverage
- **Fix tests when fixing bugs**: When fixing a bug, update/add tests to prevent regression
- **Test data accuracy**: Ensure test data matches expected behavior (e.g., word counts in validation tests)

**CRITICAL - Cursor Cost Management (2026-01-24)**:
- **Model selection**: Use `auto` model (cheapest) by default. Only use `gpt-5.2` for critical tasks requiring maximum quality.
- **Context constraints**: Always specify exact files when requesting fixes. Never ask to "fix everything" or "refactor entire codebase" - this sends millions of tokens.
- **Exclude large directories**: Always exclude `node_modules`, `.next`, `dist`, `build` from context. Add explicit exclusions: "Don't include node_modules, .next, or dist".
- **On-demand limit**: Set on-demand usage limit to $0 (or max $5) in Cursor dashboard to prevent surprise charges.
- **Background agents**: Disable Cloud Agents and Bugbot when not actively needed. They consume tokens continuously.
- **Monitor daily**: Check Cursor usage dashboard daily. If costs spike, identify the exact request/model that caused it.
- **Single-file focus**: When possible, work on one file at a time to reduce context size per request.
- **Cost red flags**: If any request costs > $1.00 or includes > 1M tokens cache read, investigate and constrain context immediately.
- **Reference**: See `CURSOR_COST_LEAK_FIX.md` for detailed cost analysis and fixes.

### 5) Ship checklist
- Contract still holds (`tests/contracts/report-flow.contract.md`).
- Reproducer test passes.
- No unrelated diffs.


