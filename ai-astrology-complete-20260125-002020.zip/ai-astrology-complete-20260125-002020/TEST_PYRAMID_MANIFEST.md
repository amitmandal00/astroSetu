# Test Pyramid Manifest

## Test Structure
All tests are in: astrosetu/tests/

### Unit Tests
- tests/unit/ (17 files)
  - Core unit tests for utilities, helpers, and components
  - Test files: *.test.ts, *.test.tsx

### Integration Tests
- tests/integration/ (13 files)
  - API integration tests
  - Controller sync tests
  - Report generation lifecycle tests
  - Payment/refund scenario tests
  - Test files: *.test.ts

### E2E Tests
- tests/e2e/ (60+ spec files)
  - Critical flow tests
  - Payment flow tests
  - Subscription flow tests
  - Report generation tests
  - Navigation flow tests
  - Test files: *.spec.ts

### Regression Tests
- tests/regression/ (10 files)
  - Weekly issues replication
  - Historical bug regression tests
  - Test files: *.test.ts

### Critical Tests
- tests/critical/ (2 files)
  - Build imports test
  - Build no-env-local test
  - Test files: *.test.ts

### Test Helpers
- tests/e2e/test-helpers.ts
- tests/integration/setup.ts
- tests/setup.ts

### Test Scripts
- package.json contains:
  - test:unit
  - test:integration
  - test:e2e
  - test:critical
  - test:regression
  - ci:critical
  - stability:full

