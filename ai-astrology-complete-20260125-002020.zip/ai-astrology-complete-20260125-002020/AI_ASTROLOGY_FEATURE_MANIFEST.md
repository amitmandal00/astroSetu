# AI Astrology Feature Slice Manifest

## Pages
- src/app/ai-astrology/page.tsx (landing)
- src/app/ai-astrology/input/page.tsx (birth details input)
- src/app/ai-astrology/preview/page.tsx (report preview)
- src/app/ai-astrology/pay/page.tsx (API-first one-time payment)
- src/app/ai-astrology/subscription/page.tsx (subscription dashboard)
- src/app/ai-astrology/bundle/page.tsx (bundle reports)
- src/app/ai-astrology/faq/page.tsx (FAQ)
- src/app/ai-astrology/access/page.tsx (private beta access)
- src/app/ai-astrology/payment/success/page.tsx (payment success)
- src/app/ai-astrology/payment/cancel/page.tsx (payment cancel)
- src/app/ai-astrology/subscription/success/page.tsx (subscription success)
- src/app/ai-astrology/year-analysis-2026/page.tsx (year analysis)

## API Routes
- src/app/api/ai-astrology/generate-report/route.ts
- src/app/api/ai-astrology/process-report-queue/route.ts
- src/app/api/ai-astrology/input-session/route.ts
- src/app/api/ai-astrology/create-checkout/route.ts
- src/app/api/ai-astrology/create-order/route.ts (API-first one-time payments)
- src/app/api/ai-astrology/authorize-order/route.ts
- src/app/api/ai-astrology/order-status/route.ts
- src/app/api/billing/subscription/route.ts
- src/app/api/billing/subscription/verify-session/route.ts
- src/app/api/billing/subscription/cancel/route.ts
- src/app/api/beta-access/verify/route.ts

## Libraries
- src/lib/ai-astrology/reportGenerator.ts (main report generator)
- src/lib/ai-astrology/reportStore.ts (Supabase storage)
- src/lib/ai-astrology/orderStore.ts (API-first orders + PaymentIntent state)
- src/lib/ai-astrology/prompts.ts (AI prompts)
- src/lib/ai-astrology/payments.ts (payment handling)
- src/lib/ai-astrology/pdfGenerator.ts (PDF generation)
- src/lib/ai-astrology/types.ts (TypeScript types)
- src/lib/ai-astrology/dateHelpers.ts (date utilities)
- src/lib/ai-astrology/ensureFutureWindows.ts (future window validation)
- src/lib/ai-astrology/reportValidation.ts (report validation)
- src/lib/ai-astrology/returnToValidation.ts (returnTo validation)
- src/lib/ai-astrology/freeReportGating.ts (free report gating)
- src/lib/ai-astrology/chargeback-defense.ts (chargeback defense)
- src/lib/ai-astrology/invoice.ts (invoice generation)
- src/lib/ai-astrology/kundliCache.ts (kundli caching)
- src/lib/ai-astrology/reportCache.ts (report caching)
- src/lib/ai-astrology/openAICallTracker.ts (OpenAI usage tracking)
- src/lib/ai-astrology/paymentToken.ts (payment token handling)
- src/lib/ai-astrology/priceFormatter.ts (price formatting)
- src/lib/ai-astrology/staticContent.ts (static content)
- src/lib/ai-astrology/testimonials.ts (testimonials)
- src/lib/ai-astrology/dailyGuidance.ts (daily guidance)
- src/lib/ai-astrology/mockContentGuard.ts (mock content guard)

## Components
- src/components/ai-astrology/ (if any specific components exist)

