# Cursor Operational Guide (AstroCursor)

## Goal
Use Cursor as a **safe autopilot**: keep moving forward, never corrupt the repo, and always leave a clean audit trail when blocked.

## MVP goals contract (must drive all decisions)
**Primary intent**: a simplified, robust solution (NOT over-engineered) with minimal dependency on third‑party schedulers (cron allowed only as a backstop).

**One‑line MVP definition**:
> “A user pays once, waits calmly, always gets a report or no charge — and the system never leaks money or breaks under retries.”

- **1) Payment protection**: manual capture; capture only after report is `completed` with content; failures never capture; opportunistic cleanup + cron backstop; no double charges (idempotent).
- **2) Robust generation UX**: async worker; frontend order→poll→render; single status vocabulary `processing|completed|failed`; preview reload resumes polling; never auto re-enqueue.
- **3) No cost leakage**: no OpenAI/Prokerala before payment authorization; `max_attempts=2`; OpenAI timeout ≤ 25s; degrade once on Prokerala failure then fail cleanly; no infinite retries.
- **4) Fast perceived performance**: redirect to preview quickly; progress vocabulary queued→generating→validating→ready; first feedback <2s; no blank screens >3s.
- **5) Stable build**: strict status vocabulary; hardened worker auth; one job = one report = one payment; no stuck processing/orphan payments.
- **6) Quality without over-engineering**: minimum section validation; fallback sections; quality metrics logged (not blocking when minimum bar met).
- **7) Retry rules**: retry only if `failed`; within 24h; max 1 manual retry; reuse same authorized PaymentIntent; no double-billing; then auto-cancel/expire.
- **8) Not in MVP**: streaming tokens UI, full bundle API-first migration, multi-language engines, human support workflows, perfect astrology depth.

## Daily workflow (recommended)
- **Before starting**: read `CURSOR_PROGRESS.md` and `CURSOR_ACTIONS_REQUIRED.md`.
- **While working**:
  - Change **≤ 5 files per batch**.
  - Prefer **tests-first** for regressions (add/extend a test that reproduces the defect).
  - After each batch: update `CURSOR_PROGRESS.md`.
- **When blocked** (approvals/popups/rate limits): log it in `CURSOR_ACTIONS_REQUIRED.md` and continue with the next safe work.

## Testing workflow (stability bar)
- **Fast local**: `npm run test:unit` → `npm run test:integration`
- **Stability**: `npm run test:regression`
- **Build gate**: `npm run verify`
- **Critical pipeline**: `npm run ci:critical`
- **One-command stability**: `npm run stability:full` (from `astrosetu/`)

## Fast E2E (recommended defaults)
- **Run against production-like server**: prefer `next build && next start` over `next dev` for E2E runs that must be reliable.
- **Parallelize**: use Playwright workers (`--workers=4` or `--workers=50%`) once tests are stable.
- **Shard in CI**: split into multiple CI jobs (`--shard=1/4`, `--shard=2/4`, …) to reduce wall-clock time.
- **Separate slow invariants**: “first-load / cold-start” specs should be tagged and run separately (nightly or a dedicated gate), not on every small change.

## Avoid Cursor timeouts / “User aborted request”
- **Always tee long runs to logs** (and preferably background them) so progress continues even if UI/tool output is interrupted:
  - `npm run test:all-layers 2>&1 | tee .cursor-test-all-layers.log`
  - `npx playwright test 2>&1 | tee .cursor-e2e.log`

## Product invariants (must never regress)
- **Timer monotonic**: generation timer must not reset to 0 mid-run; must not get stuck while loader is visible.
- **Future-only predictions**: no past-dated prediction windows/years in report output (20xx < current year).
- **Subscription journey**: “Subscribe” must not loop back to the same page; verify-session must persist and survive refresh.

## Where the guardrails live
- `.cursor/rules`
- `CURSOR_AUTOPILOT_PROMPT.md`
- `NON_NEGOTIABLES.md`

## Cursor Cost Management (CRITICAL - 2026-01-24)
- **Model selection**: Use `auto` model (cheapest) by default. Only use `gpt-5.2` for critical tasks.
- **Context constraints**: Always specify exact files. Never ask to "fix everything" - this sends millions of tokens.
- **Exclude large dirs**: Always exclude `node_modules`, `.next`, `dist`, `build` from context.
- **On-demand limit**: Set to $0 in Cursor dashboard to prevent surprise charges.
- **Background agents**: Disable Cloud Agents/Bugbot when not needed.
- **Monitor daily**: Check usage dashboard. If costs spike, identify exact request/model.
- **Single-file focus**: Work on one file at a time to reduce context size.
- **Reference**: See `CURSOR_COST_LEAK_FIX.md` for detailed cost analysis and fixes.


