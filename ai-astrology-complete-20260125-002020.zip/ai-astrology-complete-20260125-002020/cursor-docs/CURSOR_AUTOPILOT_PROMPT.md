# Cursor Autopilot Starter (paste at top of tasks)

## CURSOR AUTOPILOT MODE – minimal interruptions

**CRITICAL RULES**:
1. **Do not ask me to click things repeatedly**. If a click is required, consolidate all pending edits into ONE accept step.
2. **If blocked, update `CURSOR_ACTIONS_REQUIRED.md` with exact next actions**.
3. **Never continue with partial context. Re-run tests before proceeding**.

## MVP GOALS — FINAL TARGET STATE (do not deviate)
**Primary intent**: simplified + robust (NOT over-engineered) with minimal dependency on third‑party schedulers (cron is only a backstop).

> “A user pays once, waits calmly, always gets a report or no charge — and the system never leaks money or breaks under retries.”

- **1) Payment protection**: manual capture; capture only after `completed` with content; failures never capture; opportunistic cleanup + cron backstop; no double charges (idempotency).
- **2) Robust generation UX**: async worker; frontend order→poll→render; `processing|completed|failed` only; preview reload resumes polling; never auto re-enqueue.
- **3) No cost leakage**: no OpenAI/Prokerala before payment auth; `max_attempts=2`; OpenAI timeout ≤ 25s; degrade once then fail cleanly; no infinite retries.
- **4) Fast perceived performance**: redirect to preview quickly; progress vocabulary queued→generating→validating→ready; first feedback <2s; no blank screens >3s.
- **5) Stable build**: strict status vocabulary; hardened worker auth; one job = one report = one payment; no stuck processing/orphan payments.
- **6) Quality without over-engineering**: minimum section validation; fallback sections; quality metrics logged (non-blocking).
- **7) Retry rules**: retry only if `failed`; within 24h; max 1 manual retry; reuse same authorized PaymentIntent; no double-billing; then auto-cancel/expire.
- **8) Not in MVP**: streaming tokens UI, full bundle API-first migration, multi-language engines, human support workflows, perfect astrology depth.

Work in **Autopilot (safe, non-blocking)** mode:
- Keep moving end-to-end; do not wait idle for popups/approvals.
- **Work in batches of one file at a time** (minimizes "Confirm edit" prompts).
- **After each edit**: run `npm run ci:critical`. If it fails, revert and try again.
- Batch changes: **≤ 3 files per batch** (prefer 1 file), one concern per batch. No repo-wide changes unless I ask.
- If the model/provider fails ("Try again/Resume"): retry with exponential backoff **30s → 60s → 120s** (3 attempts total).
  - If still failing: write exact pending steps into `CURSOR_ACTIONS_REQUIRED.md` and stop.
- If "Confirm edit" / "Accept" prompt appears:
  - **STOP making further changes** immediately.
  - Write summary to `CURSOR_ACTIONS_REQUIRED.md` including: file name, change intent, why it is safe.
  - Wait for a single "Accept", then continue automatically with the next steps.
- If an approval/popup appears (including "Allow popups safely"): **skip that action**, log it in `CURSOR_ACTIONS_REQUIRED.md`, update `CURSOR_PROGRESS.md`, and continue with the next safe task.
- **🚨 CRITICAL - GIT WORKFLOW (NON-NEGOTIABLE)**: 
  - **ALWAYS keep all changes**: Commit locally to preserve work (`git add` and `git commit` are fine)
  - **ALWAYS get approval before git push**: **NEVER** push to remote without explicit user approval
  - **Show what will be pushed**: Display commit summary and changed files before asking for approval
  - **Wait for confirmation**: Do not proceed with `git push` until user explicitly approves
  - **This is a NON-NEGOTIABLE rule that cannot be bypassed under any circumstances.**
- Always ask before terminal commands, installs, deletes, network/external APIs.
- **Run checkpoint script**: After every change, run `bash scripts/cursor-checkpoint.sh` (if available).

## Stabilization Mode (ChatGPT Feedback - CRITICAL)
**If the user says "run all tests" or "stabilize build":**
- Enter **Stabilization Mode**
- Follow PHASE 0 → PHASE 4 exactly (see `.cursor/rules` for full details)
- Do not exit early
- Success condition: `npm run ci:critical` passes AND no infinite loading states are possible
- Run: `bash scripts/cursor-stabilize.sh` to execute full stabilization workflow

## Fast E2E + No-Interruptions Defaults (2026-01-24)
- **Default E2E mode**: run against `next build && next start` (production-like) for stability; use `next dev` only for local debugging.
- **Parallelize**: use Playwright workers once stable (`--workers=4` or `--workers=50%`).
- **Shard** in CI to reduce wall time (`--shard=1/4`, `--shard=2/4`, …).
- **Never run long commands "inline-only"**: always capture logs with `tee` (and background if long-running) so Cursor UI/tool interruptions don't stop progress.

## Cursor Cost Management (CRITICAL - 2026-01-24)
- **Model selection**: Use `auto` model (cheapest) by default. Only use `gpt-5.2` for critical tasks requiring maximum quality.
- **Context constraints**: Always specify exact files when requesting fixes. Never ask to "fix everything" - this sends millions of tokens.
- **Exclude large dirs**: Always exclude `node_modules`, `.next`, `dist`, `build` from context.
- **On-demand limit**: Set to $0 in Cursor dashboard to prevent surprise charges.
- **Background agents**: Disable Cloud Agents/Bugbot when not needed - they consume tokens continuously.
- **Monitor daily**: Check usage dashboard. If costs spike, identify exact request/model.
- **Single-file focus**: Work on one file at a time to reduce context size.

## Critical Workflow Rules (ChatGPT Feedback)
- **No refactors in preview page** unless tests are added/updated first.
- **Any change touching**:
  - `preview/page.tsx`
  - `/api/ai-astrology/generate-report`
  - subscription routes
  must pass: `npm run ci:critical` locally.
- **Never add new import path** without updating the "build-imports" test.
- **Polling loops may only terminate on**: abort signal, unmount, attemptKey changed, completed/failed state.
- **Work in 1-file increments** for critical files (preview/page.tsx, polling logic).
- **After each change**: run `npm run ci:critical`.
- **If any test fails**: revert and fix tests first.
- **Do not widen scope**: Do not rename exports. Do not move files.
- **CRITICAL - Test Coverage (2026-01-21)**: 
  - Always update tests when changing code
  - Run `npm run test:unit` after every change
  - Fix failing tests immediately (they are blockers)
  - Generate coverage reports: `npm run test:unit:coverage`
  - Ensure coverage thresholds are met (Lines 70%, Functions 70%, Branches 65%, Statements 70%)

## Production Serverless Rules (ChatGPT Feedback - CRITICAL)
- **Single-surface changes**: one bug = one subsystem. No refactors unless requested.
- **No UI timer tweaks until API lifecycle is proven**: fix server first, then UI.
- **Serverless timeout config**: Any route that can exceed default execution time MUST export:
  - `export const runtime = "nodejs";`
  - `export const maxDuration = 180;` (or higher for complex reports)
  - `export const dynamic = "force-dynamic";`
- **Heartbeat required**: Long-running generation MUST update `updated_at` every 15-20s.
- **Always mark failed on error**: Catch/finally MUST call `markStoredReportFailed`.
- **Every change must pass, locally**:
  - `npm run type-check`
  - `npm run build`
  - `npm run test:critical`
- **If any one of these fails**: stop and write in `CURSOR_ACTIONS_REQUIRED.md` rather than "try random fixes".

## Autopilot Non-Negotiables (Minimize Interruptions)
- **No broad edits**: Max 1–3 files per change set (prefer 1 file at a time).
- **No refactors while fixing bugs**: Fix the bug with minimal surface area.
- **Always green before next change**: Must pass `npm run ci:critical` after every change set.
- **If confirmation required**: write `CURSOR_ACTIONS_REQUIRED.md` first, then pause.
- **Never proceed after connection error** without logging next actions to `CURSOR_ACTIONS_REQUIRED.md`.
- **Single-file edits**: When possible, edit one file at a time to reduce "Confirm edit" prompts.
- **Consolidate edits**: If multiple files need changes, batch them into ONE accept step when possible.
- **CRITICAL - Test Coverage (2026-01-21)**: Always update tests when making code changes. Run `npm run test:unit` after every change. Fix failing tests immediately - they are blockers.


