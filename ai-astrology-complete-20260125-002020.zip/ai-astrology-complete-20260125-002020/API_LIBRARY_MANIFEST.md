# API and Library Manifest

## API Routes
All API routes are in: astrosetu/src/app/api/

### Astrology APIs
- /api/astrology/kundli
- /api/astrology/match
- /api/astrology/horoscope
- /api/astrology/panchang
- /api/astrology/muhurat
- /api/astrology/numerology
- /api/astrology/remedies
- /api/astrology/dasha
- /api/astrology/dosha

### AI Astrology APIs
- /api/ai-astrology/generate-report
- /api/ai-astrology/input-session
- /api/ai-astrology/create-checkout

### Billing APIs
- /api/billing/subscription
- /api/billing/subscription/verify-session
- /api/billing/subscription/cancel

### Beta Access APIs
- /api/beta-access/verify

## Libraries
All libraries are in: astrosetu/src/lib/

### Core Libraries
- astrologyAPI.ts (Prokerala integration)
- astrologyEngine.ts (mock engine)
- validators.ts (input validation)
- apiHelpers.ts (API helpers)
- supabase.ts (Supabase client)

### AI Astrology Libraries
See AI_ASTROLOGY_FEATURE_MANIFEST.md for complete list

