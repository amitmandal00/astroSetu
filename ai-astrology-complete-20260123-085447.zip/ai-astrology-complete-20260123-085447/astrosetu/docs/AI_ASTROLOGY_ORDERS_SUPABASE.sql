-- API-first Orders table for one-time AI Astrology reports (PaymentIntent manual capture)
-- Purpose:
-- - Separate payment authorization lifecycle from report generation lifecycle
-- - Support idempotent retries without double-charging
-- - Allow safe: AUTHORIZE -> GENERATE -> CAPTURE or CANCEL

create table if not exists public.ai_astrology_orders (
  id text primary key, -- orderId (server generated)
  idempotency_key text not null unique, -- clientRequestId or stable key to prevent duplicates
  report_id text not null unique,
  report_type text not null,
  input jsonb not null,
  amount integer not null,
  currency text not null default 'aud',

  -- Stripe
  payment_intent_id text not null unique,
  payment_intent_client_secret text, -- safe to store; client needs it if local storage is lost

  -- Lifecycle
  status text not null check (status in ('created','authorized','captured','cancelled','failed','expired')),
  authorized_at timestamptz,
  captured_at timestamptz,
  cancelled_at timestamptz,
  failed_at timestamptz,
  expires_at timestamptz, -- optional: authorization window

  error_message text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists ai_astrology_orders_status_idx
  on public.ai_astrology_orders (status);

create index if not exists ai_astrology_orders_created_at_idx
  on public.ai_astrology_orders (created_at desc);

create index if not exists ai_astrology_orders_report_type_idx
  on public.ai_astrology_orders (report_type);


