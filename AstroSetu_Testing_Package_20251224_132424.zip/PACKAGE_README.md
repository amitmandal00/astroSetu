# AstroSetu Testing Package for ChatGPT

This package contains all the documentation and instructions needed for ChatGPT to perform comprehensive testing of the AstroSetu application.

## Files Included

1. **CHATGPT_TESTING_INSTRUCTIONS.md** - Start here! Instructions for ChatGPT on how to test
2. **TESTING_GUIDE_FOR_CHATGPT.md** - Comprehensive testing guide with all test scenarios
3. **TEST_SCENARIOS_DETAILED.md** - Detailed step-by-step test scenarios
4. **NOTIFICATIONS_SETUP.md** - Push notification setup guide (if needed)
5. **SUPABASE_SETUP.md** - Database setup guide (if needed)
6. **QUICK_SETUP_GUIDE.md** - Quick setup instructions
7. **README.md** - Application overview

## How to Use This Package

1. **For ChatGPT**: Start with `CHATGPT_TESTING_INSTRUCTIONS.md` - it contains all the instructions
2. **For Manual Testing**: Use `TESTING_GUIDE_FOR_CHATGPT.md` as your testing checklist
3. **For Detailed Scenarios**: Refer to `TEST_SCENARIOS_DETAILED.md` for step-by-step instructions

## Application Structure

- **Web App**: Next.js application in `astrosetu/` directory
- **Mobile App**: React Native application in `astrosetu/mobile/` directory
- **Runs on**: `http://localhost:3001` (web)

## Quick Start

1. Navigate to `astrosetu/` directory
2. Run `npm install` (if not done)
3. Run `npm run dev`
4. Open `http://localhost:3001` in browser
5. Start testing!

## Test Credentials (if needed)

- Email: `test@example.com`
- Password: `Test123!@#`
- Test Card: `4111 1111 1111 1111` (Razorpay test)

## Important Notes

- App works in **demo mode** without API keys (uses mock data)
- Some features require API configuration (see setup guides)
- Push notifications need VAPID keys (see NOTIFICATIONS_SETUP.md)
- Payments need Razorpay test credentials

## Support

If you encounter issues during testing:
1. Check browser console for errors
2. Check network tab for failed requests
3. Verify environment variables are set
4. Review error messages carefully

---

**Package Created**: $(date)
**Version**: 1.0.0
