-- API-first Orders table for one-time AI Astrology reports (PaymentIntent manual capture)
-- Purpose:
-- - Separate payment authorization lifecycle from report generation lifecycle
-- - Support idempotent retries without double-charging
-- - Allow safe: AUTHORIZE -> GENERATE -> CAPTURE or CANCEL

create table if not exists public.ai_astrology_orders (
  id text primary key, -- orderId (server generated)
  idempotency_key text not null unique, -- clientRequestId or stable key to prevent duplicates
  report_id text not null unique,
  report_type text not null,
  input jsonb not null,
  amount integer not null,
  currency text not null default 'aud',

  -- Stripe
  payment_intent_id text unique, -- nullable for bypass mode
  payment_intent_client_secret text, -- safe to store; client needs it if local storage is lost
  payment_mode text not null default 'stripe' check (payment_mode in ('stripe','bypass')),
  capture_status text not null default 'pending' check (capture_status in ('pending','captured','voided','skipped','failed')),

  -- Lifecycle
  status text not null check (status in ('created','authorized','captured','cancelled','failed','expired')),
  authorized_at timestamptz,
  captured_at timestamptz,
  cancelled_at timestamptz,
  failed_at timestamptz,
  expires_at timestamptz, -- optional: authorization window

  error_message text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- If the table already existed (common), the CREATE TABLE above won't add new columns/constraints.
-- Apply idempotent migrations here so running this file is always safe.

-- Columns
alter table public.ai_astrology_orders
  add column if not exists payment_mode text;

alter table public.ai_astrology_orders
  add column if not exists capture_status text;

alter table public.ai_astrology_orders
  add column if not exists payment_intent_client_secret text;

-- Ensure payment_intent_id is nullable (bypass mode)
alter table public.ai_astrology_orders
  alter column payment_intent_id drop not null;

-- Backfill + defaults + NOT NULL
update public.ai_astrology_orders
  set payment_mode = 'stripe'
  where payment_mode is null;

alter table public.ai_astrology_orders
  alter column payment_mode set default 'stripe';

alter table public.ai_astrology_orders
  alter column payment_mode set not null;

update public.ai_astrology_orders
  set capture_status = 'pending'
  where capture_status is null;

alter table public.ai_astrology_orders
  alter column capture_status set default 'pending';

alter table public.ai_astrology_orders
  alter column capture_status set not null;

-- Constraints (idempotent)
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'ai_astrology_orders_payment_mode_chk'
  ) then
    alter table public.ai_astrology_orders
      add constraint ai_astrology_orders_payment_mode_chk
      check (payment_mode in ('stripe','bypass'));
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'ai_astrology_orders_capture_status_chk'
  ) then
    alter table public.ai_astrology_orders
      add constraint ai_astrology_orders_capture_status_chk
      check (capture_status in ('pending','captured','voided','skipped','failed'));
  end if;
end $$;

create index if not exists ai_astrology_orders_status_idx
  on public.ai_astrology_orders (status);

create index if not exists ai_astrology_orders_created_at_idx
  on public.ai_astrology_orders (created_at desc);

create index if not exists ai_astrology_orders_report_type_idx
  on public.ai_astrology_orders (report_type);

create index if not exists ai_astrology_orders_report_id_idx
  on public.ai_astrology_orders (report_id);

create index if not exists ai_astrology_orders_capture_status_idx
  on public.ai_astrology_orders (capture_status);


