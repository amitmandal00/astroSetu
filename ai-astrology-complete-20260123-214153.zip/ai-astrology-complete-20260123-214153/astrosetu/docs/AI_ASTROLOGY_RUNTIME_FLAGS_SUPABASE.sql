-- Runtime flags / KV store for AI Astrology operational switches.
-- Purpose:
-- - Persist short-lived operational flags across serverless instances
-- - Example: prokerala_disabled_until to avoid repeated slow/failing calls when credits are exhausted

create table if not exists public.ai_astrology_runtime_flags (
  key text primary key,
  value_json jsonb not null,
  updated_at timestamptz not null default now()
);

create index if not exists ai_astrology_runtime_flags_updated_at_idx
  on public.ai_astrology_runtime_flags (updated_at desc);


